import Message from '../models/message.js';

var controller = {
    // Function to save a message
    save: async (req, res) => {
        var params = req.body;
        var message = new Message();
        message.message = params.message;
        message.from = params.from;
        console.log(message);

        try {
            let messageStored = await message.save();
            return res.status(200).send({
                status: 'Success',
                messageStored
            });
        } catch (error) {
            return res.status(404).send({
                status: 'error',
                message: 'No ha sido posible guardar el mensaje'
            });
        }
    },

    // Function to get messages
    getMessages: async (req, res) => {
        try {
            let messages = await Message.find({}).sort('-_id').exec();
            
            // If there are no messages
            if (!messages.length) {
                return res.status(404).send({
                    status: "error",
                    message: "No hay mensajes para mostrar"
                });
            }

            return res.status(200).send({
                status: "success",
                messages
            });
        } catch (error) {
            return res.status(500).send({
                status: 'error',
                message: "Error al extraer los datos"
            });
        }
    }
};

export default controller;