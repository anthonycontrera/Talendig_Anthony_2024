// routes/message.js
import { Router } from 'express';
import controller from '../controllers/message.js';

const router = Router();

router.post('/save', controller.save); // Ruta para guardar mensajes
router.get('/messages', controller.getMessages); // Ruta para obtener mensajes

export default router;
