// index.js
import express from 'express';
import morgan from 'morgan';
import { Server as SocketServer } from 'socket.io';
import http from 'http';
import cors from 'cors';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import router from './routes/message.js';

// Conexión a MongoDB
const url = 'mongodb://localhost:27017/messages_db';

mongoose.Promise = global.Promise;

const app = express();
const PORT = 4000;

// Crear el servidor con el módulo http
const server = http.createServer(app);
const io = new SocketServer(server, {
    cors: {
        origin: '*'
    }
});

// Middlewares
app.use(cors())
app.use(morgan('dev'))
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json())
app.use('/api', router)

io.on('connection', (socket) =>{
console.log(socket.id)
console.log('Usuario conectado')

socket.on('message', (message, apodo) => {
    //Envio de Mensajes a todo los usuarios conectado
    socket.broadcast.emit('message', {
        body: message,
        from:apodo
    })

  })

})

// Conexión a la Base de Datos y escuchar la app por el puerto
mongoose.connect(url)
    .then(() => {
        console.log('Conexión a la BD con éxito');
        server.listen(PORT, () => {
            console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
        });
    })
    .catch(err => {
        console.error('Error al conectar a la BD:', err);
    })

    